package com.project.eureka.security;

import java.util.Map;

import com.project.eureka.domain.User;

public interface SecurityTokenGenerator {
    Map<String,String> generateToken(User user);//token and message -> the return type can be String also
}
