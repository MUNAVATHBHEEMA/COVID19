package com.project.eureka.service;

import com.project.eureka.domain.User;
import com.project.eureka.exception.InvalidCredentialsException;
import com.project.eureka.exception.UserAlreadyExistsException;

public interface UserService {
	User saveUser(User user) throws UserAlreadyExistsException;
    //user name and password is in database or not, if not save
    User findByEmailAndPassword(String email,String password) throws InvalidCredentialsException;


}
