package com.project.eureka.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.eureka.domain.User;
import com.project.eureka.exception.InvalidCredentialsException;
import com.project.eureka.exception.UserAlreadyExistsException;
import com.project.eureka.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	private UserRepository userRepository;

	@Autowired
	public UserServiceImpl(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@Override
	public User saveUser(User user) throws UserAlreadyExistsException {

		if (this.userRepository.findByEmail(user.getEmail()) != null) {
			throw new UserAlreadyExistsException();
		}
		System.out.println(user);

		return userRepository.save(user);
	}

	@Override
	public User findByEmailAndPassword(String email, String password) throws InvalidCredentialsException {
		System.out.println("email" + email);
		System.out.println("password" + password);
		User loggedInUser = userRepository.findByEmailAndPassword(email, password);
		System.out.println(loggedInUser);
		if (loggedInUser == null) {
			throw new InvalidCredentialsException();
		}

		return loggedInUser;
	}
}