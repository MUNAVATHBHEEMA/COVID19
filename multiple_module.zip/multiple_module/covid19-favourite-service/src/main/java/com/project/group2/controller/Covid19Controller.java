package com.project.group2.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.project.group2.service.Covid19Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.project.group2.entity.User;
import com.project.group2.repository.UserRepository;

@RestController
@RequestMapping("/api")
public class Covid19Controller {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private Covid19Service service;
	
	@PostMapping("/addAll")
	public User addAll(@RequestBody User user){
		
		return userRepository.save(user);
	}


	@GetMapping("/getFav/{email}")
	public List<User> getFav(@PathVariable String email){
		List<User> covid19 = userRepository.findAll();
		List<User> allList = covid19.stream().filter(x-> x.getEmail().equals(email)&& x.isFavourite()==true)
				.collect(Collectors
               .toCollection(ArrayList::new));
		return allList;
	}


	@GetMapping("/getAll")
	public List<User> All(){
		return service.getAll();
	}

	@PostMapping("/addList")
	public List<User> addList(@RequestBody List<User> user){
		return service.saveList(user);
	}

	@DeleteMapping("/delete/{userId}")
	public String deleteUserById(@PathVariable int userId){
		return service.deleteUser(userId);
	}

	@GetMapping("/user/{email}")
	public User Search(@PathVariable String email){
		return service.searchByEmail(email);
	}
	@PutMapping("/update")
	public User update(@RequestBody User user){
		return service.updateUser(user);
	}

}
