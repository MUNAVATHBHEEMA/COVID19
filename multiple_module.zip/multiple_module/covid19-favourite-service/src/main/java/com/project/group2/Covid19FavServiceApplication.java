package com.project.group2;

import java.util.Collections;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class Covid19FavServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Covid19FavServiceApplication.class, args);
	}
	@Bean
	public Docket swaggerConfiguration(){
		//return a prepared docket instance
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				.paths(PathSelectors.ant("/api/*"))
				.apis(RequestHandlerSelectors.any())
				.build()
				.apiInfo(apiDetails());
	}

	private ApiInfo apiDetails(){
		return new ApiInfo(
				"COVID19 Details API",
				"Sample API for showing swagger documentation",
				"0.0.1-SNAPSHOT",
				"Free to use",
				new springfox.documentation.service.Contact("MUNAVATH BHEEMA","http://abc.com","abc@gmail.com"),
				"Api License",
				"http:license.com",
				Collections.emptyList());
	}
	
}
