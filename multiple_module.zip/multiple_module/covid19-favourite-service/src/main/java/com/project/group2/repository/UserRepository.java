package com.project.group2.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.group2.entity.User;

public interface UserRepository extends JpaRepository<User, Integer>{

	//String save(String email);
	User findByEmail(String email);
	User deleteById(int userId);

	//String deleteByEmailAndUserId(String email, int userId);

	//String getEmail(String email);


}
