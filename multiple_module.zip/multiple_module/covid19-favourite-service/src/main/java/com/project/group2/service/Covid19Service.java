package com.project.group2.service;

import org.springframework.beans.factory.annotation.Autowired;
import com.project.group2.repository.UserRepository;
import com.project.group2.entity.User;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Covid19Service {
    @Autowired
    UserRepository userRepository;

    public List<User> getAll(){
        return userRepository.findAll();
    }

    public List<User> saveList(List<User> user){
        return userRepository.saveAll(user);
    }


    public String deleteUser(int userId){
        userRepository.deleteById(userId);
        return "User deleted with id:"+userId;
    }

    public User searchByEmail(String email){
        return userRepository.findByEmail(email);
    }

    public User updateUser(User user){
        User existingUser = userRepository.findById(user.getUserId()).orElse(null);
        existingUser.setEmail(user.getEmail());
        existingUser.setFavourite(user.isFavourite());
        existingUser.setCovid19(user.getCovid19());
        return userRepository.save(existingUser);
    }
}
