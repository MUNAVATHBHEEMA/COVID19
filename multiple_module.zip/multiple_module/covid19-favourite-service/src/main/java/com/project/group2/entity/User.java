package com.project.group2.entity;

import java.util.List;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name="user_table")
public class User {
	@Id
	@GeneratedValue
	int userId;
	@Column(length = 100)
	private String email;
	private boolean isFavourite;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id",referencedColumnName = "userId")
	private List<Covid19> Covid19;
	
	
	

}
