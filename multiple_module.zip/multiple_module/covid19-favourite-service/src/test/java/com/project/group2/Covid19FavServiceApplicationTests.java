//package com.project.group2;
package com.project.group2;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
public class Covid19FavServiceApplicationTests {
    @Test
    public void contextLoads() {
    }
}
