package com.itcinfotech.multiple_module;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultipleModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultipleModuleApplication.class, args);
	}

}
