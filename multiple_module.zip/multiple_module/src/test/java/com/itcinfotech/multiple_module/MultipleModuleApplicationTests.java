package com.itcinfotech.multiple_module;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultipleModuleApplicationTests {

	@Test
	public void contextLoads() {
	}

}
